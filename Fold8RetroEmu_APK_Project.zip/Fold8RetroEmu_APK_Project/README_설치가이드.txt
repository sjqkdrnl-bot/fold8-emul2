[폴드8 올인원 에뮬레이터 APK 빌드 가이드]

이 프로젝트에는 갤럭시 Z 폴드 8의 실제 내부 저장소(/storage/emulated/0) 폴더를
삼성 '내 파일'처럼 직접 읽고 전체화면 자동 회전을 지원하는 안드로이드 네이티브 코드가 포함되어 있습니다.

▶ 방법 1: PC 없이 2분 만에 APK 자동 생성 (GitHub Actions - 가장 쉬움)
1. GitHub(github.com)에 새 저장소(Repository)를 하나 만듭니다.
2. 이 압축 파일의 모든 파일을 해당 저장소에 업로드(Push)합니다.
3. 상단 [Actions] 탭 → 'Build Fold8 Retro Emulator APK' 완료 후
   하단 Artifacts의 'Fold8RetroEmu-APK'를 눌러 app-debug.apk를 다운로드합니다.
4. 폴드 8에서 app-debug.apk를 눌러 설치하고 '모든 파일 접근 권한'을 허용하면 실제 폰 폴더를 바로 불러옵니다.

▶ 방법 2: PC Android Studio에서 바로 APK 뽑기
1. Android Studio에서 이 폴더를 엽니다.
2. 상단 메뉴 [Build] → [Build Bundle(s) / APK(s)] → [Build APK(s)] 클릭.
3. app/build/outputs/apk/debug/app-debug.apk 파일을 폴드 8로 옮겨 설치합니다.
