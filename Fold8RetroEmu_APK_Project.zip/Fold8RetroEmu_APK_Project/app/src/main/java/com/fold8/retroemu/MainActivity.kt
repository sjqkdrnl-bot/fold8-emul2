package com.fold8.retroemu

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AndroidStorageBridge(), "AndroidStorage")
        webView.loadUrl("file:///android_asset/index.html")

        ensureAllFilesPermission()
    }

    private fun ensureAllFilesPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:$packageName")
                    startActivity(intent)
                } catch (_: Exception) {
                    val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    startActivity(intent)
                }
            }
        }
    }

    inner class AndroidStorageBridge {
        @JavascriptInterface
        fun getRootPath(): String {
            return Environment.getExternalStorageDirectory().absolutePath
        }

        @JavascriptInterface
        fun listDir(path: String): String {
            val dir = File(path)
            val result = JSONArray()
            val files = dir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: emptyList()
            for (f in files) {
                if (f.name.startsWith(".")) continue
                val obj = JSONObject()
                obj.put("name", f.name)
                obj.put("path", f.absolutePath)
                obj.put("isDir", f.isDirectory)
                obj.put("size", if (f.isDirectory) 0 else f.length())
                result.put(obj)
            }
            return result.toString()
        }

        @JavascriptInterface
        fun readFileBase64(path: String, maxBytes: Int): String {
            val file = File(path)
            if (!file.exists() || !file.isFile) return ""
            val limit = minOf(file.length(), maxBytes.toLong()).toInt()
            val buffer = ByteArray(limit)
            file.inputStream().use { it.read(buffer, 0, limit) }
            return Base64.encodeToString(buffer, Base64.NO_WRAP)
        }

        @JavascriptInterface
        fun setImmersiveFullscreen(enable: Boolean) {
            runOnUiThread {
                if (enable) {
                    window.decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    )
                } else {
                    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                }
            }
        }
    }
}
